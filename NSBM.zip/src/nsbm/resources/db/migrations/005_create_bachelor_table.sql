CREATE TABLE bachelors(
  id varchar(8) PRIMARY KEY
);