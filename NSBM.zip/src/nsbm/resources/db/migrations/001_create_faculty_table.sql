CREATE TABLE faculties(
  code varchar(8) PRIMARY KEY,
  name varchar(50),
  telephone varchar(10)
)