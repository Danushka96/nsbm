CREATE TABLE masters(
  id varchar(8) PRIMARY KEY
)