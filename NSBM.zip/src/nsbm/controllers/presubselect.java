package nsbm.controllers;

import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ToggleGroup;

public class presubselect {

    @FXML
    private JFXTextField regnumber;

    @FXML
    private JFXRadioButton under;

    @FXML
    private ToggleGroup stutype;

    @FXML
    private JFXRadioButton post;

    @FXML
    void editreg(ActionEvent event) {

    }

    @FXML
    void newreg(ActionEvent event) {

    }

}